# CM3191 Ferrocene — Short lab report, LaTeX source (v6.9)

Inorganic Experiment 2, AY2026/27 Sem 1. Body (Title, Aims, Results & Discussion, Conclusion,
References) fits three A4 pages of text; with the three inline figures it runs to four pages,
figures being excluded from the limit. Remaining figures follow the references; appendices A–E
hold the calculations, isotope envelope, original spectra, signed datasheets and MSB photographs.

## Build

    make            # recalculate -> tests -> latexmk (XeLaTeX, two passes; no Biber)

Requirements: XeLaTeX with the IBM Plex OpenType fonts from the TeX Live package `plex`
(Serif, Sans, Mono and IBM Plex Math; the .otf file names are referenced directly), unicode-math,
mhchem, siunitx, booktabs, tabularx, cite, titlesec, hyperref, caption, float, placeins, pdfpages,
graphicx; Python 3.
Regenerating the NMR and ESI figures additionally needs nmrglue, numpy, scipy, matplotlib,
pdftocairo and the system IBM Plex Sans/Mono fonts (scripts/process_nmr.py, scripts/plot_esi.py).

Switches at the top of report.tex: `\draftmarkstrue` shows the grey CONFIRM boxes (set
`\draftmarksfalse` for submission); `\figsinlinefalse` compiles the body without the inline
figures to check the three-page text limit. Submission file name: A0266094X.pdf.

## Layout

| path | content |
|---|---|
| `report.tex` | the report: IBM Plex Serif body, Plex Sans headings and title block, Plex Mono for data-set and file names, Plex Math; centred title block, numbered sections, superscript citations, ACS-style reference list (layout of the CM3191 report drafts) |
| `data/inputs.json` | every input with a status (confirmed / assumed / nominal / pending / literature) and its record page |
| `data/calculations.json` | derived values from `scripts/recalculate.py` |
| `data/nmr_results.json`, `data/esi_results.json` | processed spectral values |
| `data/isotope_rows.tex`, `data/predicted_isotopes.csv` | calculated ESI envelope |
| `data/photo_manifest.json`, `data/source_manifest.json`, `data/source_files_sha256.json` | provenance (originals and their hashes) |
| `data/build_checks.json` | last verified build state |
| `scripts/recalculate.py`, `scripts/test_calculations.py` | calculation and report-consistency tests (7) |
| `scripts/check_assets.py` | all TeX dependencies are local |
| `scripts/process_nmr.py`, `scripts/plot_esi.py` | figure regeneration from the raw data |
| `sources/` | manual, signed records, raw Bruker NMR directory, ESI export (.docx + LibreOffice PDF), photographs, micrographs |
| `assets/` | figure files used by report.tex |
| `archive_report_v5_fullcontent.tex`, `style_v5_archive.tex` | the v5 full-content draft (IBM Plex, biblatex; not built here) |

## Items to confirm before submission (also marked in the PDF)

1. The manual requires the ε calculation handwritten on the UV printout; annotate it and replace the scan
   in sources/spectra_record.pdf (p. 2), then set `\draftmarksfalse` and save as A0266094X.pdf.

Confirmed on 9 October 2026: vial + crude 1.6127 g (crude 0.0699 g, 6.2 %; sublimation recovery 75 %);
UV stock measured undiluted (D = 1); UV weighed mass 0.0232 g; second crude portion 0.3021 g (IMG_8546);
MSB temperature 23 °C (Canvas announcement).
