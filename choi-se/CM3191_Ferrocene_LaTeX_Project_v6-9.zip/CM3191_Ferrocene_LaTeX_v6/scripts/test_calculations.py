#!/usr/bin/env python3
"""Checks that the numbers quoted in report.tex agree with data/calculations.json (v6)."""
from __future__ import annotations
import json, re, unittest
from decimal import Decimal as D
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class ReportNumbers(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.c = json.loads((ROOT / 'data/calculations.json').read_text())
        cls.i = json.loads((ROOT / 'data/inputs.json').read_text())
        cls.tex = (ROOT / 'report.tex').read_text(encoding='utf-8')

    def quoted(self, text: str) -> None:
        self.assertIn(text, self.tex, f'report.tex does not quote: {text}')

    def test_stoichiometry(self) -> None:
        s = self.c['stoichiometry']
        self.assertAlmostEqual(float(s['n_CpH_mmol']), 12.10, places=2)
        self.assertAlmostEqual(float(s['n_FeCl2_mmol']), 6.677, places=3)
        self.assertAlmostEqual(float(s['theoretical_ferrocene_g']), 1.1258, places=4)
        self.quoted('12.10~mmol'); self.quoted('6.677~mmol'); self.quoted('1.1258')

    def test_yields_and_statuses(self) -> None:
        m = self.c['masses_and_yields']
        self.assertEqual(D(m['crude_g']), D('0.0699'))
        self.assertAlmostEqual(float(m['crude_yield_percent']), 6.21, places=2)
        self.assertAlmostEqual(float(m['isolated_yield_percent']), 4.67, places=2)
        self.assertAlmostEqual(float(m['sublimation_recovery_original_percent']), 75.3, places=1)
        self.assertAlmostEqual(float(m['sublimation_recovery_extra_percent']), 59.7, places=1)
        self.assertEqual(D(m['original_sublimate_residue_g']), D('0.0094'))
        self.assertEqual(m['crude_status'], 'confirmed')
        self.assertNotIn('1.8127', self.tex)
        self.quoted('0.0699'); self.quoted('6.2\\%'); self.quoted('4.7\\%'); self.quoted('75'); self.quoted('59.7\\%')

    def test_uv(self) -> None:
        u = self.c['uv_vis']
        self.assertAlmostEqual(float(u['concentration_M']), 4.988e-3, delta=2e-6)
        self.assertAlmostEqual(float(u['epsilon_M-1cm-1']['440.50']), 83.4, places=1)
        self.assertAlmostEqual(float(u['epsilon_M-1cm-1']['325.00']), 47.9, places=1)
        self.assertEqual(u['dilution_status'], 'confirmed'); self.assertEqual(u['mass_status'], 'confirmed')
        self.assertIn('undiluted', self.tex)
        self.quoted('= 83~'); self.quoted('= 48~'); self.quoted('4.988\\times10^{-3}')
        self.assertFalse(self.i['uv_handwritten_calculation_on_printout']['value'])
        self.assertIn('handwrite the', self.tex)              # pending action visible in the draft

    def test_msb(self) -> None:
        m = self.c['msb']
        self.assertEqual(D(m['net_mass_g']), D('0.0867'))
        self.assertTrue(m['entered_mass_matches'])
        self.assertIsNone(m['experimental_moment_BM'])
        self.assertNotIn('\\mu_{\\mathrm{eff}} \\leq', self.tex)   # no numerical bound in the report
        self.assertAlmostEqual(float(m['chi_g_literature_cm3_g']), -6.7e-7, delta=2e-8)
        self.assertAlmostEqual(float(m['chi_g_one_unpaired_electron_cm3_g']), 6.8e-6, delta=1e-7)
        self.assertEqual(m['T_K'], '296.15'); self.quoted('23~$^\\circ$C (296~K)')
        self.quoted('0.10--0.12~g')                            # manual's sample-mass range

    def test_nmr_limit_conversion(self) -> None:
        # integral 0.01 on the Cp-H = 10.00 scale is 1 mol% for a one-proton impurity
        self.assertIn('roughly 1~mol\\% of a one-proton impurity', self.tex)
        self.assertNotIn('below 0.1~mol', self.tex)

    def test_isotope_envelope(self) -> None:
        rows = self.c['esi_predicted_envelope_percent']
        self.assertEqual([r['nominal_mz'] for r in rows], [184, 185, 186, 187, 188, 189])
        self.assertEqual(D(rows[2]['relative_percent']), D(100))
        self.assertTrue(13 < float(rows[3]['relative_percent']) < 13.5)
        self.assertTrue(6.3 < float(rows[0]['relative_percent']) < 6.4)

    def test_sources_present(self) -> None:
        for n in ('8571', '8572', '8574', '8575', '8576', '8577', '8579'):
            self.assertTrue((ROOT / 'sources/photos' / f'IMG_{n}.JPG').is_file())
        for f in ('sources/nmr/CM3191-Thurs-400-Sep17-2026-09/1/fid', 'sources/esi/SN9-KIM_DONGHWAN.docx',
                  'assets/nmr/fig_nmr_full.pdf', 'assets/esi/fig_esi.pdf', 'assets/selected_records.pdf'):
            self.assertTrue((ROOT / f).is_file(), f)
        micro = self.i['micrographs']['value']
        self.assertIn('IMG_D62D3C4F8565-1', micro['sublimate_extra'])
        self.assertIn('sources/microscopy/IMG_D62D3C4F8565-1.JPEG', self.tex)


if __name__ == '__main__':
    unittest.main(verbosity=2)
