# Revision history

## v7.1

- Appendix C note shortened: the remark that the calculation was added on the scan is removed
  (the participant had permission to annotate the scan).

## v7.0 — submission build

- Handwritten ε calculation (participant, iPad on the signed UV scan) received: sources/spectra_record.pdf
  rebuilt as original IR page + annotated UV page; the unannotated original kept; manifests updated.
- Figure 7 caption and Appendix C note updated; last CONFIRM marker removed; \draftmarksfalse.
- Build: 19 pages, text body 3 pages, 0 overfull/underfull/undefined, tests 7/7, assets verified.

## v6.12

- Zero-reading photo (IMG_8576): per the participant the reading was zero and the photo caught the
  display mid-refresh (not a reflection). Figure 8 (1), Appendix E caption and Section 2.6 updated.

## v6.11 — evidence-level revision (third external review)

- MSB tare: the earlier claim that 0.8223 g "appears in both subtractions" was wrong; the final
  line reads 0.9090 − 0.8264 = 0.0867 (arithmetically inconsistent). Section 2.6, Appendix A and
  the Figure 10 caption now quote it as written; 0.8223 is a reconstruction, net mass unverifiable.
- Magnetic result reframed as inconclusive: the mass mode showed 0.000 where −0.007 is expected,
  and χv/ρ (ρ < 1.5 g cm⁻³) implies ≤ −0.003 in mass mode, so the two modes disagree. The
  "ten times the zero offset" argument (circular: offset not measured) and "establishes the
  absence of unpaired electrons" are removed; only "neither reading is positive" is kept.
- IR: "five IR-active fundamentals" → "five characteristic bands in the recorded range"; the
  peak-picked weak bands at 1631–1775, 1255 and 1190 cm⁻¹ are now acknowledged and left
  unassigned; the unsupported combination-band assignment removed.
- NMR: no quantitative detection limit (mol%) without an internal standard; ¹³C-satellite
  expectation explained as p/(1−p) per C–H; integrals stated as normalised to 10; the 1.25 ppm
  aliphatic signal kept in the conclusion.
- Yield: "loss in reaction, not purification" → "dominated by losses before sublimation"; green
  quench no longer used as evidence (iron was in excess); crude-purity bound stated as conditional.
- UV: 1 % budget called illustrative; causes of the 9 % shortfall "may contribute, cannot be
  separated"; transition assignment attributed to Sohn et al. with D5d labels; envelope not resolved.
- ESI: no claim that ferrocene cannot be protonated; source oxidation given as the known mechanism;
  isotope contributions given as ratios to the base peak (10.8 %, 2.3 %); "peak for peak" → within
  about one percentage point.
- Microscopy: "evidence of purification" → "consistent with recrystallisation by sublimation".
- DMSO volume stated as in the manual (15 mL plus a rinse); manual reference page range corrected
  (Expt 2 pp 12–22; MSB appendix p 23).
- Conclusion rewritten at the evidence level; tests updated (no mol% limit, tare quoted as written).

## v6.10 — wording from an external review

- "At least three-quarters of the crude was ferrocene" softened to "most", with the caveat that
  water condensed on the cycle-1 cover may have been weighed with the sublimate.
- Stated explicitly that only the first sublimate was characterised by NMR, IR and ESI-MS and that
  the UV–Vis and magnetic results assume the same composition for the second.
- Conclusion: "Every technique identifies…" → "Every technique is consistent with ferrocene and
  none shows an impurity". Not adopted: the reviewer's request to remove the CONFIRM marker (it is
  a draft switch) and to fill blank datasheet fields after the fact.

## v6.9 — crude mass and UV dilution confirmed

- Vial + crude confirmed as 1.6127 g: crude 0.0699 g (6.2 %), sublimation recovery of the original
  crude 75.3 % (isolated yield 4.7 % unchanged). The loss narrative is reversed accordingly: the
  low yield arose in the reaction and work-up, sublimation was efficient (75 % and 60 %), and the
  75 % recovery bounds non-ferrocene mass in the crude to under a quarter. Table 1, Section 2.1,
  Sources of error, Conclusion and Appendix A updated; the crude-mass CONFIRM box removed.
- UV stock measured undiluted (D = 1) confirmed; CONFIRM box removed; wording "undiluted".
- Inline NMR and ESI figures at 0.8\textwidth so the figure-inclusive body stays at four pages;
  text-only body three pages.
- Remaining marker: handwritten ε calculation on the UV printout (scan to replace).

## v6.8

- UV weighed mass 0.0232 g confirmed by the participant (the 'UV: 0.0232 g' note on W6 p.4);
  CONFIRM box narrowed to the dilution factor.

## v6.7 — extra crude mass evidenced

- IMG_8546 added (sources/photos/): the second crude portion taken out of its vial and weighed on
  tared weighing paper, 0.3021 g. Resolves the apparent mismatch with the "1.4447 g initially
  (with vial)" note, which is the gross mass as received. Appendix E now "Weighing and
  magnetic-balance photographs" with this photo as panel (a); Section 2.1 says "weighed on
  tared paper". inputs.json and photo_manifest.json updated.

## v6.6 — Canvas announcements incorporated

- Magnetic measurement temperature: 23 °C (296 K), the instrument-room value recorded by the
  laboratory staff (Canvas, 26 Sep 2026). CONFIRM box for T removed; the S = 1/2 comparison
  value is evaluated at 296.15 K (recalculate.py reads the temperature from inputs.json).
- ESI-MS settings (Canvas, 24 Sep 2026): Thermo LTQ XL ion trap, flow injection in methanol
  after 1:100 dilution of the methanol stock, capillary 43 V, no added electrolyte, sodium
  present in the system. The text now explains why no [M+H]+ and no [M+Na]+ (m/z 209, absent)
  form and why the radical cation arises by oxidation at the emitter (electrospray source as an
  electrolytic cell; Van Berkel & Zhou 1995 cited).
- Two references added (Van Berkel 1995; the two announcements as one entry); text trimmed and
  vertical spacing tightened (parskip 1.5 pt, section spacing) to keep three text pages.
- Remaining CONFIRM items: vial + crude mass; UV mass and dilution; handwritten ε on the UV
  printout.

## v6.5 — IBM Plex and new title

- Fonts: IBM Plex Serif (body), Plex Sans (title block, section headings, caption labels),
  Plex Mono (data-set and file names), IBM Plex Math via unicode-math. Figures regenerated with
  Plex Sans/Mono. Layout retuned for the wider face: 10 pt, 19 mm margins, linespread 1.02;
  text still three pages without the inline figures.
- Title: "CM3191 Inorganic Experiment 2: Synthesis and Characterisation of Ferrocene";
  British spelling unified (characterisation).
- The note under v6.4 about Termes being intentional is superseded: the participant asked for
  Plex on 9 October.

## v6.4 — corrections from the v6.3 review

- NMR detection limit: an integral of 0.01 on the Cp-H = 10.00 scale is about 1 mol% for a
  one-proton impurity (0.1–0.2 mol% for the 6–12-proton candidates); the earlier "0.1 mol%"
  was a tenfold slip. Water/acetone now "most likely from solvent and glassware", not asserted.
- Magnetic susceptibility: no numerical moment or bound is assigned (the zero offset was not
  characterised and the literature diamagnetism is of the same size as the offset); the
  conclusion rests on the tenfold gap between the observed zero and the S = 1/2 expectation.
  Appendix A keeps only the display-comparison values. Manual's sample mass corrected to
  0.10–0.12 g.
- Yield: the 4.7 % isolated yield is stated as independent of the overwritten crude mass; the
  crude yield and recoveries are marked conditional; "technique, not chemistry" softened to a
  suggestion with its assumption (similar ferrocene content of the two crudes) stated.
- UV–Vis: D = 1 stated as taken, not proven; tolerances labelled as typical values; the claim
  that the handwritten ε calculation is on the printout removed (it is not) and turned into a
  pending action.
- IR / ESI / conclusion: identification language replaces purity guarantees ("not detectable",
  "confirms the formula; not quantitative for composition"; "every technique identifies").
- Colour observations phrased as "consistent with".
- Pipeline: inputs.json rewritten with a status per value; recalculate.py and
  test_calculations.py rewritten for the v6 model (7 tests, including report-consistency
  checks); README rewritten; build_checks.json and the hash manifest regenerated.
- Layout to keep three text pages after the additions: linespread 1.05, parskip 2 pt.
- Note on the review's point 7: TeX Gyre Termes is intentional (the house style the
  participant chose); IBM Plex belongs to the archived v5 only.

## v6.3

- Figure 8 now shows the five photographs the manual requires, in procedure order:
  zero reading (IMG_8576, display washed out, stated in the caption), length entry
  (IMG_8574), weight entry (IMG_8575), chi_v (IMG_8577), chi_g (IMG_8579). The balance
  and ruler photographs (IMG_8571/8572) and the display crops stay in Appendix E.

## v6.2

- Micrograph attribution corrected by the participant: IMG_D62D3C4F8565-1 (100 µm bar)
  is the second-portion sublimate at the manual's magnification and is now Figure 1c in
  the body; IMG_A0BE3981A218-1 (60 µm bar) is an over-magnified field of the same
  batch and moves to the Figures section as supplementary. Batch marker removed.

## v6.1

- Figure 1 in the body now has three panels: crude, sublimate of the original crude
  (NMR/ESI-MS/IR batch) and sublimate of the second crude portion (UV–Vis/MSB batch);
  the fourth micrograph (second field, batch unconfirmed) stays in the Figures section.
  Pagination unchanged (text 3 pp; 4 pp with inline figures).

## v6 — short-report format (house style) and 3-page cut

- report.tex rewritten in the house style of the CM3191 report drafts
  (article 10.5 pt, A4, 20 mm margins, TeX Gyre Termes/Heros, centred title block,
  numbered sections "1.", superscript citations via cite, ACS-style thebibliography).
  biblatex/biber and style.tex are no longer used; the v5 full-content draft is kept as
  archive_report_v5_fullcontent.tex (needs the v5 preamble; not built here).
- Body = Title, Aims, Results & Discussion (2.1–2.7), Conclusion, References:
  3 A4 pages of text (checked with igsinlinefalse); with the three inline figures
  (micrographs, full NMR, ESI-MS) the body runs to 4 pages, figures being excluded
  from the limit. Remaining figures (micrographs 2, NMR expansions, IR, UV–Vis, MSB)
  follow the references in a Figures section; appendices A–E after that.
- Draft markers: \pend{} boxes (CONFIRM: vial+crude; UV mass/dilution; MSB temperature;
  micrograph batch) are shown while \draftmarkstrue; set \draftmarksfalse for submission.
- Build: 20 pages, 0 overfull, 0 undefined.

## v5.1 — ESI-MS incorporated

- Added the instrument export sources/esi/SN9-KIM_DONGHWAN.docx (ion trap, +ESI, full scan
  70–1400, 17 Sep 2026 17:56) and its LibreOffice PDF rendering; scripts/plot_esi.py re-plots
  the vector trace (assets/esi/fig_esi.pdf) and writes data/esi_results.json.
- Observed cluster (base = 100): 184 6.5, 185 0.7, 186 100, 187 14.2, 188 1.2 vs calculated
  6.4 / 0.7 / 100 / 13.2 / 1.1; no [M+H]+ beyond ~1 %, no [2M+H]+, no fragments > 5 %.
- Section 2.7, Table 3, Figure 7, Appendix C (printout pages) and the conclusion updated;
  "extra" portion confirmed by the participant as a second crude issue after the low first yield.
- Build: 27 pages; 0 overfull, 0 underfull, 0 undefined.

## v5 — full-content short-report draft (lecture-notes structure)

- report.tex rewritten into the required structure: Title, Aims, Results & Discussion
  (data analysis and spectral interpretation), Conclusion, References, then a Figures
  section and Appendices A–F (calculations, isotope envelope, signed spectra, signed
  datasheets, MSB photographs, confirmation list). Body not yet cut to three pages.
- Datasheet re-read at 300–600 dpi; the following were resolved and entered:
  FeCl2·4H2O 1.3274 g; vial 1.5428 g / vial+crude 1.8127 g → crude 0.2699 g (24.0 %);
  cover masses for all sublimation cycles (A 48.6311/48.6714, B 45.7720/45.7843,
  re-weighed covers 45.7688/45.8792 and 48.6305/48.6868, dish 58.9177/58.9315);
  residue of original sublimate 1.1083 − 1.0989 = 0.0094 g (< 20 mg → extra portion);
  extra crude 0.3021 g → 0.1805 g (59.7 %); UV mass 0.0232 g in 25 mL, D = 1 →
  ε440 = 83, ε325 = 48 M⁻¹ cm⁻¹; MSB empty tube 0.8223 g (both handwritten subtractions)
  → 0.0867 g confirmed, "0.8264" identified as a copying slip.
- Literature verified from primary sources: Sohn (thesis, Table II) / Sohn–Hendrickson–Gray
  JACS 1971: 22 700 cm⁻¹ ε 91, 30 800 cm⁻¹ ε 49 (EPA), d–d assignments; χM(ferrocene)
  −125×10⁻⁶ cgs (Sohn Table I after Engelmann 1953); Lippincott–Nelson 1958 IR bands.
- Magnetic discussion rewritten as a bound: |χg| ≲ 5×10⁻⁷, μeff ≤ 0.5 μB, S = 1/2 excluded
  by > 10×; Pascal-correction artefact explained.
- The v4 working report is kept as archive_report_v4_working.tex (not built).
- Build: XeLaTeX + Biber, 24 pages (body pp. 1–6, references to p. 7, figures pp. 8–11,
  appendices pp. 12–24); 0 overfull, 0 underfull, 0 undefined.

## v4 — own 1H NMR dataset incorporated

- Added the student's own Bruker dataset CM3191-Thurs-400-Sep17-2026-09 (expno 1,
  procno 1; 400.23 MHz, CDCl3, 297.9 K, zg30, NS 8, D1 1 s) unmodified under
  sources/nmr/, with scripts/process_nmr.py, data/nmr_results.json and two figures
  (assets/nmr/): the full 0-10 ppm spectrum with every signal integrated and the
  data-set name shown, and expansions of the Cp-H and 0.8-2.6 ppm regions.
- Rewrote Section 3.5: axis re-referenced to residual CHCl3 = 7.26 ppm (instrument
  axis 7.284); Cp-H singlet 4.17 ppm (10.00), 13C satellites 175 Hz (0.12, calc. 0.11),
  acetone 2.17 (0.21), water 1.55 (3.73), aliphatic 1.25 (0.13); detection limit
  ~0.01 on the Cp-H = 10.00 scale; water and acetone treated as solvent/handling
  residues, not as properties of the solid.
- Table 4 is the only float allowed to move ([!tb]); all other floats remain [H].
- Added bibliography entries nmrdata (own data) and powers2017 (secondary
  literature shift, flagged for replacement by SDBS or a primary source).
- Updated draft-status box, conclusion, Appendix C title and figures, checklist
  P07, inputs.json (schema 4; NMR removed from missing evidence), header DRAFT 04.
- Build: XeLaTeX + Biber, 27 pages, 0 overfull, 0 underfull, 0 undefined.

## v3 — microscopy, sample provenance, instrument IDs and IBM Plex

- Incorporated all four supplied microscopy originals; retained their colour,
  embedded annotations and scale bars. Stage/batch mappings remain qualified.
- Recorded the participant's recollection about extra material after insufficient
  original recovery; kept original synthesis yield separate from supplementary
  material and did not assign all analyses to the extra batch.
- Confirmed laboratory unit 1 / identification label 8143007934 (24465 also visible).
  Corrected the overstrict assumption that a manufacturer's serial number was
  required. Kept the mass-result close-up's separate ID-coverage limit explicit.
- Replaced unavailable-microscopy placeholders with actual observations; added
  the confirmed matriculation label to the title block.
- Applied IBM Plex Serif, Sans, Mono and Math explicitly, using TeX-distributed font
  names. No font binaries are bundled. The manuscript uses grayscale throughout;
  original photographs/scans are not recoloured.
- Added complete result frames, not just display crops, to preserve unit labels.
- Preserved all earlier measurement values, null fields and conditional arithmetic.
- Refreshed source manifests, tests and editing handover.

## v2 — magnetic photographs

Added seven photographs, complete V/M display strings and a conditional net-mass
reconciliation. The original and supplementary sublimation masses were separated.
