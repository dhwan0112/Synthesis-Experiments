# CM3191 Ferrocene — Short lab report, LaTeX source (v7.0, submission build)

Inorganic Experiment 2, AY2026/27 Sem 1. Body (Title, Aims, Results & Discussion, Conclusion,
References) fits three A4 pages of text; with the three inline figures it runs to four pages,
figures being excluded from the limit. Remaining figures follow the references; appendices A–E
hold the calculations, isotope envelope, original spectra, signed datasheets and MSB photographs.

## Build

    make            # recalculate -> tests -> latexmk (XeLaTeX, two passes; no Biber)

Requirements: XeLaTeX with the IBM Plex OpenType fonts from the TeX Live package `plex`
(Serif, Sans, Mono and IBM Plex Math; the .otf file names are referenced directly), unicode-math,
mhchem, siunitx, booktabs, tabularx, cite, titlesec, hyperref, caption, float, placeins, pdfpages,
graphicx; Python 3.
Regenerating the NMR and ESI figures additionally needs nmrglue, numpy, scipy, matplotlib,
pdftocairo and the system IBM Plex Sans/Mono fonts (scripts/process_nmr.py, scripts/plot_esi.py).

Switches at the top of report.tex: `\draftmarkstrue` shows the grey CONFIRM boxes (set
`\draftmarksfalse` for submission); `\figsinlinefalse` compiles the body without the inline
figures to check the three-page text limit. Submission file name: A0266094X.pdf.

## Layout

| path | content |
|---|---|
| `report.tex` | the report: IBM Plex Serif body, Plex Sans headings and title block, Plex Mono for data-set and file names, Plex Math; centred title block, numbered sections, superscript citations, ACS-style reference list (layout of the CM3191 report drafts) |
| `data/inputs.json` | every input with a status (confirmed / assumed / nominal / pending / literature) and its record page |
| `data/calculations.json` | derived values from `scripts/recalculate.py` |
| `data/nmr_results.json`, `data/esi_results.json` | processed spectral values |
| `data/isotope_rows.tex`, `data/predicted_isotopes.csv` | calculated ESI envelope |
| `data/photo_manifest.json`, `data/source_manifest.json`, `data/source_files_sha256.json` | provenance (originals and their hashes) |
| `data/build_checks.json` | last verified build state |
| `scripts/recalculate.py`, `scripts/test_calculations.py` | calculation and report-consistency tests (7) |
| `scripts/check_assets.py` | all TeX dependencies are local |
| `scripts/process_nmr.py`, `scripts/plot_esi.py` | figure regeneration from the raw data |
| `sources/` | manual, signed records, raw Bruker NMR directory, ESI export (.docx + LibreOffice PDF), photographs, micrographs |
| `assets/` | figure files used by report.tex |
| `archive_report_v5_fullcontent.tex`, `style_v5_archive.tex` | the v5 full-content draft (IBM Plex, biblatex; not built here) |

## Submission state (11 October 2026)

All items confirmed; `\draftmarksfalse` is set and the PDF carries no CONFIRM markers.
Submission file: `A0266094X.pdf` (deadline 19 Oct 2026, 10:00, Canvas, "Expt. 2 short lab report submission").
The UV page of `sources/spectra_record.pdf` now carries the handwritten ε calculation (iPad, on the signed
scan; `sources/uv_annotated.jpeg`); the unannotated original is `sources/spectra_record_unannotated.pdf`.
The MSB tare record remains inconsistent (final line written 0.9090 − 0.8264 = 0.0867) and is quoted as written.
