#!/usr/bin/env python3
"""Verify bundled original bytes and local TeX dependencies (standard library only).

Run from any working directory. Font and TeX-package installations are environment
prerequisites, not document-specific assets; see README.md.
"""
from __future__ import annotations
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def checked_path(relative: str) -> Path:
    path = (ROOT / relative).resolve()
    if ROOT not in path.parents:
        raise ValueError(f'External path is not allowed: {relative}')
    if not path.is_file():
        raise FileNotFoundError(f'Missing asset: {relative}')
    return path


def check_hash(relative: str, expected: str) -> None:
    path = checked_path(relative)
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        raise ValueError(f'Original bytes changed: {relative}')


def main() -> None:
    photos = json.loads((ROOT / 'data/photo_manifest.json').read_text(encoding='utf-8'))['photos']
    records = json.loads((ROOT / 'data/source_manifest.json').read_text(encoding='utf-8'))
    for row in photos:
        check_hash(row['file'], row['sha256'])
    for row in records:
        check_hash(row['project_path'], row['sha256'])
    pattern = re.compile(r'\\(?:input|includegraphics|includepdf|addbibresource)(?:\[[^\]]*\])?\{([^{}]+)\}')
    dependencies: set[str] = set()
    for tex in (ROOT / 'report.tex', ROOT / 'style_v5_archive.tex'):
        for relative in pattern.findall(tex.read_text(encoding='utf-8')):
            if '#' not in relative:
                checked_path(relative)
                dependencies.add(relative)
    font_files = [p for p in ROOT.rglob('*') if p.suffix.lower() in ('.ttf', '.otf', '.woff', '.woff2', '.pfb')]
    if font_files:
        raise ValueError('Font binaries must not be bundled: ' + ', '.join(str(p.relative_to(ROOT)) for p in font_files))
    print(f'Verified {len(photos)} original photographs and {len(records)} original PDFs.')
    print(f'Verified {len(dependencies)} local TeX dependencies; no external document paths or font binaries.')


if __name__ == '__main__':
    main()
