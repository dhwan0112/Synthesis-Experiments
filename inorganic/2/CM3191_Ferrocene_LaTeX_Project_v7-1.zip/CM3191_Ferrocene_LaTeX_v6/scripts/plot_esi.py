#!/usr/bin/env python3
"""Re-plot the ESI-MS printout (sources/esi/SN9-KIM_DONGHWAN.docx) from its vector trace.

The docx holds two EMF pages (full scan 70-1400 and the 170-210 expansion). LibreOffice
converts them to PDF (sources/esi/SN9-KIM_DONGHWAN_libreoffice.pdf); pdftocairo -svg gives
the trace as one long path. m/z is calibrated on the instrument's own peak labels. Output:
assets/esi/fig_esi.pdf/.png and the intensities in data/esi_results.json (observed block).
"""
import json, re, subprocess, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import rcParams
rcParams.update({"font.family": "IBM Plex Sans", "font.size": 8, "axes.linewidth": 0.6, "pdf.fonttype": 42, "savefig.dpi": 600})

PDF = "sources/esi/SN9-KIM_DONGHWAN_libreoffice.pdf"
OUT = "assets/esi"; import os; os.makedirs(OUT, exist_ok=True)

def trace(page):
    svg = f"/tmp/esi_p{page}.svg"
    subprocess.run(["pdftocairo", "-svg", "-f", str(page), "-l", str(page), PDF, svg], check=True)
    s = open(svg).read()
    items = re.findall(r'<path[^>]*d="([^"]+)"', s); items.sort(key=len, reverse=True)
    v = np.array(list(map(float, re.findall(r"[-+]?\d*\.?\d+", items[0])))).reshape(-1, 2)
    x, y = v[:, 0], v[:, 1]
    h = (y - y.min()) / (y.max() - y.min()) * 100.0        # y grows upward in this group; min = baseline
    return x, h

def calibrate(x, h, labels):
    """labels: {mz_label: approx_fraction_of_x_range}; fit x -> m/z on the apexes nearest the labels."""
    pk = [i for i in range(1, len(h) - 1) if h[i] > h[i - 1] and h[i] >= h[i + 1] and h[i] > 0.8]
    xs, ms = [], []
    for mz, frac in labels.items():
        xt = x.min() + frac * (x.max() - x.min())
        i = min(pk, key=lambda k: abs(x[k] - xt)); xs.append(x[i]); ms.append(mz)
    a, b = np.polyfit(xs, ms, 1); return a * x + b

# ---- expansion (page 2): frame 170-210; labelled apexes 184.04, 185.96, 186.96, 188.04
x2, h2 = trace(2)
mz2 = calibrate(x2, h2, {184.04: (184.04 - 170) / 40, 185.96: (185.96 - 170) / 40, 188.04: (188.04 - 170) / 40})
# ---- full scan (page 1): frame 70-1400; labelled apexes 185.96, 469.32, 1391.44
x1, h1 = trace(1)
mz1 = 70 + (x1 - x1.min()) / (x1.max() - x1.min()) * 1330.0      # frame mapping ...
mz1 = mz1 + (185.96 - mz1[np.argmax(h1)])                         # ... shifted so the base peak sits on its label

def apex(mz, h, m, w=0.45):
    sel = (mz > m - w) & (mz < m + w); return float(h[sel].max()) if sel.any() else 0.0
obs = {m: round(apex(mz2, h2, m), 1) for m in (183, 184, 185, 186, 187, 188)}
calc = {184: 6.37, 185: 0.70, 186: 100.0, 187: 13.24, 188: 1.10, 189: 0.06}
print("observed", obs)

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.0, 2.8), gridspec_kw={"width_ratios": [1.25, 1]})
ax1.plot(mz1, h1, color="black", lw=0.6)
ax1.set_xlim(70, 1400); ax1.set_ylim(0, 108); ax1.set_xlabel("$m/z$"); ax1.set_ylabel("relative abundance / %")
ax1.spines[["top", "right"]].set_visible(False)
ax1.set_title("(a) full scan, $m/z$ 70–1400", loc="left", fontsize=8)
ax1.annotate("185.96\n[Fe(C$_5$H$_5$)$_2$]$^{+\\bullet}$", xy=(186, 100), xytext=(330, 92), fontsize=7, ha="left",
             arrowprops=dict(arrowstyle="-", lw=0.5))
for m, lab in ((469.3, "469.32"), (152.9, "152.92")):
    ax1.annotate(lab, xy=(m, apex(mz1, h1, m, 3)), xytext=(m + 25, apex(mz1, h1, m, 3) + 8), fontsize=6.5, color="0.35",
                 arrowprops=dict(arrowstyle="-", lw=0.4, color="0.5"))
ax2.plot(mz2, h2, color="black", lw=0.7, label="observed (SN9)")
ax2.set_xlim(181.5, 190.5); ax2.set_ylim(0, 24); ax2.set_xlabel("$m/z$")
ax2.spines[["top", "right"]].set_visible(False)
ax2.set_title("(b) molecular-ion region, vertical scale ×5", loc="left", fontsize=8)
for m, v in calc.items():
    ax2.plot([m + 0.0, m + 0.0], [0, v], color="0.45", lw=2.2, alpha=0.6, solid_capstyle="butt", zorder=0)
ax2.plot([], [], color="0.45", lw=2.2, alpha=0.6, label="calculated, C$_{10}$H$_{10}$Fe$^+$")
for m in (184, 185, 187, 188):
    v = obs[m]
    ax2.text(m, v + 0.8, f"{m}\n{v:.1f}", ha="center", va="bottom", fontsize=6.5)
ax2.text(186, 18.3, "186\n100 (off scale)", ha="center", va="bottom", fontsize=6.5,
         bbox=dict(boxstyle="square,pad=0.15", fc="white", ec="none"))
ax2.legend(loc="upper right", fontsize=6.5, frameon=False)
fig.text(0.995, 0.01, "SN9  Z:\\0_CM3191\\20260917\\SN9  #30  RT 0.51  ITMS + p ESI full ms [70–1400]  17/9/2026", ha="right",
         va="bottom", fontsize=6, family="IBM Plex Mono")
fig.tight_layout(rect=(0, 0.04, 1, 1))
fig.savefig(f"{OUT}/fig_esi.pdf"); fig.savefig(f"{OUT}/fig_esi.png")
res = json.load(open("data/esi_results.json"))
res["isotope_cluster_observed_percent"] = {str(k): v for k, v in obs.items()}
json.dump(res, open("data/esi_results.json", "w"), indent=2)
print("figure written")
