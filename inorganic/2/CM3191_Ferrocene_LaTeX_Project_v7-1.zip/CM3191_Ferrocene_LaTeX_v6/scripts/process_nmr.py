#!/usr/bin/env python3
"""CM3191 Inorganic Expt 2 (ferrocene) — 1H NMR processing.

Reads the Bruker processed spectrum (pdata/1/1r), re-references the axis to
residual CHCl3 = 7.26 ppm (Fulmer et al., Organometallics 2010, 29, 2176),
integrates every signal, measures the 13C satellites and writes:
  fig_nmr_full.{pdf,png}       full 0-10 ppm spectrum, all signals integrated, file name shown
  fig_nmr_expansion.{pdf,png}  Cp-H region with 13C satellites + minor-signal region
  nmr_results.json             all numbers used in the report
"""
import json
import numpy as np
import nmrglue as ng
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import rcParams

SRC = "sources/nmr/CM3191-Thurs-400-Sep17-2026-09/1"
NAME = "CM3191-Thurs-400-Sep17-2026-09"
OUT = "assets/nmr"

rcParams.update({"font.family": "IBM Plex Sans", "font.size": 8,
                 "axes.linewidth": 0.6, "xtick.direction": "out",
                 "pdf.fonttype": 42, "savefig.dpi": 600})

# ---------------------------------------------------------------- read
dic, data = ng.bruker.read_pdata(f"{SRC}/pdata/1")
p = dic["procs"]; a = dic["acqus"]
sf, off, swp, si = p["SF"], p["OFFSET"], p["SW_p"], p["SI"]
ppm_raw = off - np.arange(si) * swp / sf / si
y = data.astype(float)

# ---------------------------------------------------------------- baseline / noise
blank = (ppm_raw > 9.0) & (ppm_raw < 10.0)
base = float(np.median(y[blank])); noise = float(y[blank].std())
y = y - base

# ---------------------------------------------------------------- referencing
m = (ppm_raw > 7.17) & (ppm_raw < 7.39)
chcl3_raw = float(ppm_raw[m][np.argmax(y[m])])
shift = 7.26 - chcl3_raw                     # Fulmer 2010: CHCl3 in CDCl3 = 7.26 ppm
ppm = ppm_raw + shift

def pk(lo, hi):
    mm = (ppm > lo) & (ppm < hi); i = np.argmax(y[mm])
    return float(ppm[mm][i]), float(y[mm][i])

def integ(lo, hi):
    mm = (ppm > lo) & (ppm < hi)
    return float(np.trapezoid(y[mm][::-1], ppm[mm][::-1]))

# operator integration regions (intrng) shifted to the referenced axis, plus 1.25 ppm
regions = [  # label, lo, hi (referenced ppm)
    ("CHCl3",   7.167229 + shift, 7.390848 + shift),
    ("Fc Cp-H", 4.030466 + shift, 4.342676 + shift),
    ("acetone", 2.089388 + shift, 2.298954 + shift),
    ("H2O",     1.438696 + shift, 1.689808 + shift),
    ("1.25",    1.20     + shift, 1.35     + shift),
]
raw = {lab: integ(lo, hi) for lab, lo, hi in regions}
ref = raw["Fc Cp-H"]
norm = {k: 10.0 * v / ref for k, v in raw.items()}   # Fc = 10.00 H

# ---------------------------------------------------------------- peak list
peaks = {lab: pk(lo, hi) for lab, lo, hi in regions}
fc_pos, fc_h = peaks["Fc Cp-H"]
mm = (ppm > 4.0) & (ppm < 4.4)
yy, xx = y[mm], ppm[mm]
idx = np.where(yy > fc_h / 2)[0]
fwhm_ppm = float(xx[idx[0]] - xx[idx[-1]]); fwhm_hz = fwhm_ppm * sf

# 13C satellites of ferrocene
sat_hi = pk(fc_pos + 0.19, fc_pos + 0.25)
sat_lo = pk(fc_pos - 0.25, fc_pos - 0.19)
J_CH = (sat_hi[0] - sat_lo[0]) * sf
sat_int = integ(sat_hi[0] - 0.02, sat_hi[0] + 0.02) + integ(sat_lo[0] - 0.02, sat_lo[0] + 0.02)
sat_norm = 10.0 * sat_int / ref
# 13C satellites of CHCl3
csat_hi = pk(7.26 + 0.20, 7.26 + 0.32); csat_lo = pk(7.26 - 0.32, 7.26 - 0.20)
J_CH_chcl3 = (csat_hi[0] - csat_lo[0]) * sf

results = {
    "dataset": NAME, "expno": 1, "procno": 1,
    "acquisition": {"date": "2026-09-17", "time_local": "20:08", "SFO1_MHz": a["SFO1"],
                    "BF1_MHz": a["BF1"], "solvent": "CDCl3", "PULPROG": a["PULPROG"], "NS": a["NS"],
                    "DS": a["DS"], "D1_s": a["D"][1], "TE_K": round(a["TE"], 1), "TD": a["TD"],
                    "SW_Hz": round(a["SW_h"], 2), "AQ_s": 2.0447, "RG": a["RG"], "P1_us": a["P"][1]},
    "processing": {"SI": si, "LB_Hz": p["LB"], "WDW": "EM", "PHC0_deg": p["PHC0"], "PHC1_deg": p["PHC1"],
                   "baseline": "flat offset = median(9-10 ppm)", "noise_sd_blank": noise},
    "referencing": {"CHCl3_as_processed_ppm": round(chcl3_raw, 4), "CHCl3_reference_ppm": 7.26,
                    "axis_shift_ppm": round(shift, 4), "source": "Fulmer et al. Organometallics 2010, 29, 2176"},
    "signals": {lab: {"delta_ref_ppm": round(peaks[lab][0], 3), "delta_as_processed_ppm": round(peaks[lab][0] - shift, 3),
                      "height": peaks[lab][1], "S_over_N": round(peaks[lab][1] / noise),
                      "region_ref_ppm": [round(lo, 3), round(hi, 3)], "integral_raw": raw[lab],
                      "integral_norm_Fc10": round(norm[lab], 3)} for lab, lo, hi in regions},
    "ferrocene": {"delta_ref_ppm": round(fc_pos, 3), "FWHM_Hz": round(fwhm_hz, 2),
                  "satellites_ref_ppm": [round(sat_lo[0], 3), round(sat_hi[0], 3)],
                  "1J_CH_Hz": round(J_CH, 1), "satellite_integral_norm_Fc10": round(sat_norm, 3),
                  "satellite_expected_norm_Fc10": round(10 * 0.0107 / 0.9893, 3)},
    "chcl3_satellites": {"ref_ppm": [round(csat_lo[0], 3), round(csat_hi[0], 3)], "1J_CH_Hz": round(J_CH_chcl3, 1)},
    "molar_ratios_vs_Fc": {"H2O": round(norm["H2O"] / 2, 3), "acetone": round(norm["acetone"] / 6, 4),
                           "CH2_units_at_1.25": round(norm["1.25"] / 2, 3)},
}
json.dump(results, open("data/nmr_results.json", "w"), indent=2)
print(json.dumps(results, indent=2))

# ---------------------------------------------------------------- figure 1: full spectrum
fig, ax = plt.subplots(figsize=(7.0, 3.6))
sel = (ppm > -0.5) & (ppm < 10.5)
ax.plot(ppm[sel], y[sel], color="black", lw=0.5)
ax.set_xlim(10.5, -0.5); ax.set_ylim(-0.03 * fc_h, 1.12 * fc_h)
ax.set_xlabel(r"$\delta$ / ppm (residual CHCl$_3$ = 7.26 ppm)")
ax.set_yticks([]); ax.spines[["left", "top", "right"]].set_visible(False)
ax.set_xticks(range(0, 11))
# integral curves and labels
for lab, lo, hi in regions:
    mm = (ppm > lo) & (ppm < hi)
    cum = np.cumsum(y[mm][::-1])[::-1]        # integral running from high to low field
    cum = cum / cum.max() if cum.max() > 0 else cum
    h = 0.16 * fc_h * (norm[lab] / 10.0) ** 0.5 + 0.02 * fc_h   # sqrt scaling keeps small ones visible
    ax.plot(ppm[mm], 0.78 * fc_h + h * (1 - cum / 1.0) * 0 + 0.78 * fc_h * 0 + h * cum, color="0.35", lw=0.7)
    ax.annotate(f"{norm[lab]:.2f}", xy=((lo + hi) / 2, 0.78 * fc_h + h + 0.02 * fc_h),
                ha="center", va="bottom", fontsize=7, color="0.2",
                bbox=dict(boxstyle="square,pad=0.1", fc="white", ec="none"))
    ax.plot([lo, hi], [0.77 * fc_h] * 2, color="0.35", lw=0.5)
# peak labels
lbl = {"CHCl3": "CHCl$_3$\n7.26", "Fc Cp-H": "Fe(C$_5$H$_5$)$_2$, 10 H\n" + f"{fc_pos:.2f} (s)",
       "acetone": f"acetone\n{peaks['acetone'][0]:.2f}", "H2O": f"H$_2$O\n{peaks['H2O'][0]:.2f}",
       "1.25": f"{peaks['1.25'][0]:.2f}"}
ypos = {"CHCl3": 0.35, "Fc Cp-H": 0.55, "acetone": 0.12, "H2O": 0.50, "1.25": 0.06}
xoff = {"CHCl3": 0, "Fc Cp-H": -0.75, "acetone": 0, "H2O": 0, "1.25": 0}
for lab, lo, hi in regions:
    ax.annotate(lbl[lab], xy=(peaks[lab][0] + xoff[lab], ypos[lab] * fc_h), ha="center", va="bottom", fontsize=7)
meta = (f"{NAME}  expno 1  procno 1\n"
        f"$^1$H, {a['SFO1']:.2f} MHz, CDCl$_3$, {a['TE']:.1f} K, zg30, NS = {a['NS']}, D1 = {a['D'][1]:.0f} s, LB = {p['LB']} Hz\n"
        f"Integrals normalised to the Cp-H singlet = 10.00")
ax.text(0.005, 0.98, meta, transform=ax.transAxes, ha="left", va="top", fontsize=6.5, family="IBM Plex Mono")
fig.tight_layout()
fig.savefig(f"{OUT}/fig_nmr_full.pdf"); fig.savefig(f"{OUT}/fig_nmr_full.png")
plt.close(fig)

# ---------------------------------------------------------------- figure 2: expansions
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.0, 2.9), gridspec_kw={"width_ratios": [1.15, 1]})
# (a) Cp-H region, x80 vertical
sel = (ppm > 3.85) & (ppm < 4.55)
ax1.plot(ppm[sel], y[sel], color="black", lw=0.6)
ax1.set_xlim(4.55, 3.85); ax1.set_ylim(-0.0008 * fc_h, 0.0125 * fc_h)
ax1.set_yticks([]); ax1.spines[["left", "top", "right"]].set_visible(False)
ax1.set_xlabel(r"$\delta$ / ppm")
ax1.set_title("(a) Cp-H region, vertical scale ×80", loc="left", fontsize=8)
for s_ in (sat_lo, sat_hi):
    ax1.annotate(f"{s_[0]:.3f}", xy=(s_[0], s_[1]), xytext=(s_[0], s_[1] + 0.0015 * fc_h), ha="center", fontsize=7,
                 arrowprops=dict(arrowstyle="-", lw=0.5))
ax1.annotate("", xy=(sat_lo[0], 0.0054 * fc_h), xytext=(sat_hi[0], 0.0054 * fc_h),
             arrowprops=dict(arrowstyle="<->", lw=0.6, shrinkA=0, shrinkB=0))
ax1.text(3.99, 0.0058 * fc_h, f"$^{{13}}$C satellites\n$^1J_{{\\mathrm{{CH}}}}$ = {J_CH:.0f} Hz\n"
         f"sum {sat_norm:.2f} (calc. {10 * 0.0107 / 0.9893:.2f})", ha="center", va="bottom", fontsize=6.5)
ax1.text(3.99, 0.0118 * fc_h, f"main singlet {fc_pos:.3f} ppm\nFWHM {fwhm_hz:.1f} Hz (off scale)", ha="center",
         va="top", fontsize=6.5, color="0.3")
ins = ax1.inset_axes([0.02, 0.58, 0.27, 0.38])
sel2 = (ppm > fc_pos - 0.05) & (ppm < fc_pos + 0.05)
ins.plot(ppm[sel2], y[sel2], color="black", lw=0.6)
ins.set_xlim(fc_pos + 0.05, fc_pos - 0.05); ins.set_yticks([]); ins.tick_params(labelsize=6)
ins.set_xticks([round(fc_pos + 0.04, 2), round(fc_pos, 2), round(fc_pos - 0.04, 2)])
ins.spines[["left", "top", "right"]].set_visible(False)
ins.set_title("main peak, full scale", fontsize=6.5, pad=2)
# (b) 0.8-2.6 ppm region
sel = (ppm > 0.8) & (ppm < 2.6)
ax2.plot(ppm[sel], y[sel], color="black", lw=0.6)
ax2.set_xlim(2.6, 0.8); ax2.set_ylim(-0.003 * fc_h, 0.08 * fc_h)
ax2.set_yticks([]); ax2.spines[["left", "top", "right"]].set_visible(False)
ax2.set_xlabel(r"$\delta$ / ppm")
ax2.set_title("(b) 0.8–2.6 ppm, vertical scale ×12", loc="left", fontsize=8)
ax2.annotate(f"H$_2$O {peaks['H2O'][0]:.2f}\n(off scale, {norm['H2O']:.2f})", xy=(peaks["H2O"][0], 0.072 * fc_h),
             ha="center", va="top", fontsize=7)
ax2.annotate(f"acetone {peaks['acetone'][0]:.2f}\n({norm['acetone']:.2f})", xy=(peaks["acetone"][0], peaks["acetone"][1]),
             xytext=(peaks["acetone"][0] + 0.02, peaks["acetone"][1] + 0.012 * fc_h), ha="center", fontsize=7)
ax2.annotate(f"{peaks['1.25'][0]:.2f}\n({norm['1.25']:.2f})", xy=(peaks["1.25"][0], peaks["1.25"][1]),
             xytext=(peaks["1.25"][0], peaks["1.25"][1] + 0.012 * fc_h), ha="center", fontsize=7)
fig.text(0.995, 0.01, f"{NAME} expno 1 procno 1, axis referenced to CHCl$_3$ = 7.26 ppm", ha="right",
         va="bottom", fontsize=6, family="IBM Plex Mono")
fig.tight_layout(rect=(0, 0.03, 1, 1))
fig.savefig(f"{OUT}/fig_nmr_expansion.pdf"); fig.savefig(f"{OUT}/fig_nmr_expansion.png")
print("figures written")
