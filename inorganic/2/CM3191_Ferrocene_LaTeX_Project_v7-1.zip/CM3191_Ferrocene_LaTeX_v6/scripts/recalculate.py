#!/usr/bin/env python3
"""Recalculate the quantities quoted in report.tex from data/inputs.json (v6 model).

Every input carries a status in inputs.json: "confirmed", "assumed" (working value the
participant must confirm; CONFIRM box in the report), "nominal" (manual value), "pending"
or "literature". Nothing is substituted for a missing measurement. Outputs:
data/calculations.json, data/isotope_rows.tex, data/predicted_isotopes.csv.
report.tex quotes the numbers directly; scripts/test_calculations.py checks that the
quoted numbers agree with calculations.json.
"""
from __future__ import annotations
import argparse, csv, io, json
from decimal import Decimal, getcontext
from pathlib import Path

getcontext().prec = 28
D = Decimal


def atomic_write(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + '.tmp'); tmp.write_text(text, encoding='utf-8'); tmp.replace(path)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    root = ap.parse_args().root.resolve()
    inp = json.loads((root / 'data/inputs.json').read_text(encoding='utf-8'))
    v = lambda k: D(str(inp[k]['value']))
    st = lambda k: inp[k]['status']

    M_fc, M_cp, M_fe, M_koh = v('molar_mass_ferrocene_g_mol'), v('cyclopentadiene_molar_mass_g_mol'), D('198.81'), D('56.11')
    n_cp = v('cyclopentadiene_volume_ml') * v('cyclopentadiene_density_g_ml') / M_cp
    n_fe = v('fecl2_4h2o_mass_g') / M_fe
    n_koh = v('koh_mass_g') / M_koh
    m_theor = n_cp / 2 * M_fc

    m_crude = v('vial_plus_crude_g') - v('empty_crude_vial_g')
    m_orig = sum(D(x) for x in inp['original_sublimation_g']['value'])
    m_extra = sum(D(x) for x in inp['extra_sublimation_g']['value'])
    residue = v('original_sublimate_vial_loaded_g') - v('original_sublimate_vial_empty_g')

    c = v('uv_weighed_mass_g') / M_fc / (v('uv_stock_volume_ml') / 1000) / v('uv_dilution_factor')
    bands = inp['uv_bands']['value']
    eps = {b['wavelength_nm']: D(b['absorbance']) / c / v('uv_path_length_cm') for b in bands}
    tol = inp['uv_assumed_tolerances']['value']
    rel_u = {b['wavelength_nm']: ((D(tol['absorbance']) / D(b['absorbance'])) ** 2 + (D(tol['mass_g']) / v('uv_weighed_mass_g')) ** 2
                                  + (D(tol['volume_ml']) / v('uv_stock_volume_ml')) ** 2 + (D(tol['path_cm']) / v('uv_path_length_cm')) ** 2).sqrt()
             for b in bands}

    m_msb = v('msb_filled_tube_g') - v('msb_empty_tube_g')
    chi_g_lit = v('chi_M_lit_cm3_mol') / M_fc
    T_msb = v('msb_temperature_K')
    chi_g_S_half = D('1.73') ** 2 / (8 * T_msb * M_fc)

    iso = {'C': [(0, D('0.9893')), (1, D('0.0107'))], 'H': [(0, D('0.999885')), (1, D('0.000115'))],
           'Fe': [(-2, D('0.05845')), (0, D('0.91754')), (1, D('0.02119')), (2, D('0.00282'))]}
    dist = {0: D(1)}
    for atom, n in (('C', 10), ('H', 10), ('Fe', 1)):
        for _ in range(n):
            nxt: dict[int, Decimal] = {}
            for i, p in dist.items():
                for j, q in iso[atom]:
                    nxt[i + j] = nxt.get(i + j, D(0)) + p * q
            dist = nxt
    env = [{'nominal_mz': 186 + k, 'relative_percent': str(100 * p / dist[0])} for k, p in sorted(dist.items()) if -2 <= k <= 3]

    out = {
        'model': 'v6 short report; statuses from inputs.json',
        'stoichiometry': {'n_CpH_mmol': str(1000 * n_cp), 'n_FeCl2_mmol': str(1000 * n_fe), 'n_KOH_mmol': str(1000 * n_koh),
                          'limiting': 'CpH', 'theoretical_ferrocene_g': str(m_theor)},
        'masses_and_yields': {
            'crude_g': str(m_crude), 'crude_yield_percent': str(100 * m_crude / m_theor), 'crude_status': st('vial_plus_crude_g'),
            'sublimate_original_g': str(m_orig), 'isolated_yield_percent': str(100 * m_orig / m_theor),
            'sublimation_recovery_original_percent': str(100 * m_orig / m_crude),
            'sublimate_extra_g': str(m_extra), 'sublimation_recovery_extra_percent': str(100 * m_extra / v('extra_crude_mass_g')),
            'extra_crude_status': st('extra_crude_mass_g'), 'original_sublimate_residue_g': str(residue)},
        'uv_vis': {'concentration_M': str(c), 'dilution_status': st('uv_dilution_factor'), 'mass_status': st('uv_weighed_mass_g'),
                   'epsilon_M-1cm-1': {w: str(e) for w, e in eps.items()},
                   'relative_uncertainty_assumed_tolerances': {w: str(u) for w, u in rel_u.items()},
                   'absorbance_ratio_440_325': str(D(bands[0]['absorbance']) / D(bands[1]['absorbance']))},
        'msb': {'net_mass_g': str(m_msb), 'tare_status': st('msb_empty_tube_g'), 'entered_mass_matches': str(m_msb) == str(v('msb_entered_mass_g')),
                'displayed_chi_v': inp['msb_volume_display']['value'], 'displayed_chi_g': inp['msb_mass_display']['value'],
                'chi_g_literature_cm3_g': str(chi_g_lit), 'chi_g_one_unpaired_electron_cm3_g': str(chi_g_S_half), 'T_K': str(T_msb),
                'experimental_moment_BM': None, 'note': 'no moment derived; zero offset not characterised'},
        'esi_predicted_envelope_percent': env,
    }
    atomic_write(root / 'data/calculations.json', json.dumps(out, indent=2) + '\n')
    rows = ''.join(f"{r['nominal_mz']} & {D(r['relative_percent']):.3f} \\\\\n" for r in env)
    atomic_write(root / 'data/isotope_rows.tex', '% Predicted values, not measured values.\n' + rows)
    buf = io.StringIO(); w = csv.writer(buf); w.writerow(['nominal_mz', 'predicted_relative_intensity_percent'])
    w.writerows((r['nominal_mz'], r['relative_percent']) for r in env)
    atomic_write(root / 'data/predicted_isotopes.csv', buf.getvalue())
    print(json.dumps(out, indent=2))


if __name__ == '__main__':
    main()
