# Participant clarifications for revision 03

## Recollection of additional material (user wording)

> 아 맞아 내가 실험도 하다가 아마 두번째 실험파트일텐데, 내가 1번째 파트에서 얻은 양이 적어서 추가로 샘플 받아서 진행했을거야...승화하고 남은 양이 모잘라서.

This is a later recollection, not a contemporaneous log. It supports the reason for
additional material, while the exact point of receipt, whether it was supplied
crude or purified, the extent of further sublimation and the assignment of each
analytical aliquot remain to be confirmed. Do not convert the word “아마” into a
verified experimental timestamp or assign all analyses to the extra sample.

## Instrument identification (user wording)

> 노란라벨에 검은색을 번호 표기된게 포함된 사진 있을텐데.

> 기기 좌하단에는 8143007934라고도 라벨링 된거 있을거야 1이라고도 써있고 기기 좌상단에는.

Inspection of IMG_8574.JPG verifies laboratory unit 1 and the lower label
8143007934 / 24465. Unit 1 also appears in IMG_8575.JPG, IMG_8576.JPG and
IMG_8577.JPG. The separate IMG_8579.JPG close-up contains no detector ID.
The manual permits “serial number/ID”; no manufacturer-serial status is asserted.

## Presentation and source delivery

The user requested grayscale manuscript styling, original colour photographs,
IBM Plex typography, and one editable ZIP containing the complete source and all
image/figure/bibliographic assets. Raw font binaries are not part of this archive;
font prerequisites are documented in README.md.
