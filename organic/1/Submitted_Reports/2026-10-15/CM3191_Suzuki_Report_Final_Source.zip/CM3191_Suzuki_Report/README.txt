CM3191 Organic Experiment 1 — Suzuki report with measured results
2026-10-12

전체 ZIP을 풀어 사용하십시오. TEX만 따로 옮기면 포함된 폰트와 그림을 찾을 수 없습니다.
본문에는 실험 기록, IR 및 Bruker NMR 결과를 반영했습니다.

MAIN FILES
  CM3191_Suzuki_Report_Revised.tex : editable source; references and structures included
  CM3191_Suzuki_Report_Revised.pdf : rendered report and supporting records

BUILD
  프로젝트 폴더에서 sh build.sh 를 실행하거나 아래 명령을 두 번 실행합니다.
  xelatex -interaction=nonstopmode -halt-on-error CM3191_Suzuki_Report_Revised.tex
  Overleaf: ZIP을 새 프로젝트로 업로드하고 main document를 위 TEX로,
  compiler를 XeLaTeX로 지정하십시오.
  기존 그림 PDF가 포함되어 있으므로 보고서 컴파일에는 Python이 필요 없습니다.

  표준 TeX Live/MiKTeX의 fontspec, amsmath, amssymb, chemfig/TikZ, booktabs,
  tabularx, enumitem, xcolor, cite, titlesec, hyperref, caption, float,
  graphicx, pdfpages, needspace가 필요합니다. TeX Live 2023에서 검증했습니다.
  fonts/: TeX Gyre Termes/Heros 및 Noto Serif CJK KR, 라이선스 포함.
  vendor/: mhchem, chemgreek, simplekv 원 배포 파일 및 라이선스.
  프로젝트 루트의 해당 스타일 파일은 일반 입력 경로용 사본입니다.

SOURCE RECORDS
  assets/experimental_scan.pdf : supplied two-page IR/working-log scan, unchanged
  assets/raw_nmr.zip           : supplied Bruker dataset, unchanged
  assets/ir.pdf                : original IR page rotated for readability
  assets/working_log.pdf       : extracted working-log page
  assets/nmr_full.pdf/.png     : measured full spectrum and weak-signal views
  assets/nmr_aromatic.pdf/.png : measured aromatic spectrum and integration windows

REPRODUCIBLE ANALYSIS
  python3 analysis/analyse_nmr.py
  Requires Python 3, NumPy, Matplotlib. No network access is needed.
  analysis/results.json : exact calculations, integration bounds and method metadata
  analysis/processed_spectrum.csv : original/referenced ppm and stored/normalised signal
  The provided processed 1r is used; the original FID is retained in raw_nmr.zip.
  No additional baseline correction, phasing, smoothing or peak removal is applied.
  Reference correction: original CHCl3 7.283795 -> 7.260000 ppm (all values shifted
  by -0.023795 ppm). Areas are trapezoidal integrals, normalised to a = 2.00.
  Routine acquisition (zg30, D1 = 1.0 s, 8 scans) is not treated as quantitative NMR.

RECORDED VALUES AND LIMITS
  Handwritten masses transcribed as 0.3502 g aryl bromide, 0.2491 g boronic acid,
  0.8340 g empty bag and 0.9502 g bag+product. Some entries are overwritten;
  the Korean front note asks the author to check this transcription.
  Product = 0.1162 g; theoretical = 0.345322 g; isolated yield = 33.6497%.
  Pd charge and 30 min reaction time are protocol values, not separate actual entries.
  Therefore Pd loading, TON and mean TOF are explicitly conditional estimates.
  Ethanol total/wash volumes, constant mass, dried appearance and IR sampling mode
  were not recorded; none has been invented.

BEFORE SUBMISSION
  The Korean front note lists remaining checks. Set draftfalse in the TEX to hide it.
  The supplied working log is not labelled as the official signed datasheet;
  its formal signature fields are blank. Add the official TA-signed form as
  assets/datasheet.pdf to include it automatically. Verify protocol details against
  actual performance before submitting the report.
