Measured supporting records and generated plots.
See the project README and analysis/analyse_nmr.py for provenance and reproduction.
The source scan and raw_nmr.zip are byte-for-byte copies of the supplied attachments.
The official signed datasheet has not been supplied; assets/datasheet.pdf is reserved
for that document and will be included automatically if present.
