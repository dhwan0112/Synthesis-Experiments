#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
xelatex -interaction=nonstopmode -halt-on-error CM3191_Suzuki_Report_Revised.tex
xelatex -interaction=nonstopmode -halt-on-error CM3191_Suzuki_Report_Revised.tex
