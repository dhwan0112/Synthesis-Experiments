#!/usr/bin/env python3
"""Reproduce Suzuki report plots/integrals from the supplied Bruker 1r.

Requires Python 3, NumPy and Matplotlib. Run from any working directory.
The archived FID and existing processing remain unchanged. No phase,
baseline, apodisation, smoothing or impurity-removal operation is applied.
"""
from pathlib import Path
import csv
import io
import json
import re
import zipfile
import xml.etree.ElementTree as ET
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "assets"
OUT = ROOT / "analysis"
with zipfile.ZipFile(ASSETS / "raw_nmr.zip") as archive:
    name = next(n for n in archive.namelist() if n.endswith("/pdata/1/procs"))
    prefix = name[:-len("procs")]
    procs = archive.read(name).decode("latin1")
    acqus = archive.read(prefix.split("pdata/")[0] + "acqus").decode("latin1")
    def scalar(text, key):
        return float(re.search(r"##\$" + key + r"=\s*([^\n]+)", text).group(1))
    assert scalar(procs, "BYTORDP") == 0 and scalar(procs, "DTYPP") == 0
    signal = np.frombuffer(archive.read(prefix + "1r"), dtype="<i4").astype(float)
    si = int(scalar(procs, "SI"))
    assert len(signal) == si
    sf = scalar(procs, "SF")
    original_ppm = scalar(procs, "OFFSET") - np.arange(si) * scalar(procs, "SW_p") / sf / si

# The supplied peaklist.xml places CHCl3 at 7.283795 ppm. Apply one
# constant axis correction to make CHCl3 = 7.260000 ppm (Fulmer et al.).
solvent_original = 7.283795
shift = 7.26 - solvent_original
ppm = original_ppm + shift
intensity = signal / signal.max()  # display normalisation only
window_specs = [("a", 8.250, 8.140), ("b", 7.760, 7.675),
                ("c", 7.675, 7.600), ("d", 7.540, 7.455),
                ("e", 7.455, 7.350)]
trapz = getattr(np, "trapezoid", None)
if trapz is None:
    trapz = np.trapz
windows = []
for label, high, low in window_specs:
    mask = (ppm <= high) & (ppm >= low)
    area = -float(trapz(intensity[mask], ppm[mask]))
    windows.append(dict(label=label, high_ppm=high, low_ppm=low, area=area))
for w in windows:
    w["relative_integral"] = 2 * w["area"] / windows[0]["area"]

# Line positions are taken from the supplied peaklist, not fitted to an
# expected product pattern. The doublet separation is invariant to shift.
doublets = {"a": [8.223296, 8.206714], "b": [7.741019, 7.724387]}
resolved = {k: {"delta": float(np.mean(v) + shift), "J_Hz": abs(v[0] - v[1]) * sf,
                "original_line_ppm": v} for k, v in doublets.items()}
mass_arbr, mass_boronic = 0.3502, 0.2491
bag, bag_product = 0.8340, 0.9502
arbr = mass_arbr / 201.02
boronic = mass_boronic / 121.93
isolated = bag_product - bag
product_mol = isolated / 198.22
# Catalyst volume/concentration and reaction time are protocol values,
# not independently entered as actual measurements on the supplied log.
pd_mol = 0.00025 * 0.001
calculations = dict(arbr_g=mass_arbr, boronic_g=mass_boronic,
                   bag_g=bag, bag_product_g=bag_product,
                   product_g=isolated, arbr_mmol=arbr * 1000,
                   boronic_mmol=boronic * 1000, boronic_equiv=boronic / arbr,
                   theoretical_g=arbr * 198.22, product_mmol=product_mol * 1000,
                   isolated_yield_percent=100 * product_mol / arbr,
                   nominal_Pd_mmol=pd_mol * 1000,
                   nominal_Pd_loading_mol_percent=100 * pd_mol / arbr,
                   nominal_TON=product_mol / pd_mol,
                   nominal_average_TOF_per_minute=product_mol / pd_mol / 30)
results = dict(source="assets/raw_nmr.zip, experiment 1/pdata/1/1r",
               method="As-supplied processed real spectrum; trapezoidal integration; no additional baseline correction",
               solvent="CDCl3", frequency_MHz=sf, NS=int(scalar(acqus, "NS")),
               pulse_program="zg30", D1_seconds=1.0,
               digital_spacing_Hz=scalar(procs, "SW_p") / si,
               chemical_shift_correction_ppm=shift, reference_CHCl3_ppm=7.26,
               windows=windows, resolved_doublets=resolved,
               calculations=calculations,
               caveat="Routine 1H data; relative aromatic integration is not a quantitative purity assay.")
(OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
with (OUT / "processed_spectrum.csv").open("w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["original_ppm", "referenced_ppm", "stored_1r_value", "normalised_intensity"])
    writer.writerows(zip(original_ppm, ppm, signal.astype(int), intensity))

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                     "axes.spines.top": False, "axes.spines.right": False,
                     "pdf.fonttype": 42, "ps.fonttype": 42})
ink, accent = "#152329", "#247979"
def style(ax, limits, ylim, minor=None):
    ax.set_xlim(*limits)
    ax.set_ylim(*ylim)
    ax.set_xlabel(r"$\delta$ / ppm")
    ax.set_ylabel("Relative intensity")
    ax.axhline(0, color="#bcc5c8", lw=.5, zorder=0)
    ax.tick_params(direction="out", length=3)
    if minor:
        ax.xaxis.set_minor_locator(MultipleLocator(minor))
def save(fig, name):
    pdf = io.BytesIO()
    fig.savefig(pdf, format="pdf")
    data = pdf.getvalue()
    assert data.rstrip().endswith(b"%%EOF")
    (ASSETS / (name + ".pdf")).write_bytes(data)
    png = io.BytesIO()
    fig.savefig(png, format="png", dpi=220)
    (ASSETS / (name + ".png")).write_bytes(png.getvalue())
    plt.close(fig)

fig, axes = plt.subplots(3, 1, figsize=(9.1, 9.0), gridspec_kw={"height_ratios": [1.35, 1, .72]})
fig.subplots_adjust(left=.10, right=.98, top=.91, bottom=.06, hspace=.53)
fig.suptitle(r"$^1$H NMR of the isolated material | 500.13 MHz, CDCl$_3$", x=.10, ha="left", fontsize=13, fontweight="bold")
ax = axes[0]
ax.plot(ppm, intensity, color=ink, lw=.65)
style(ax, (16.2, -3.9), (-.025, 1.12), 1)
ax.set_title("A  Full acquired spectral range", loc="left", fontsize=10)
ax.annotate(r"CHCl$_3$ 7.26", (7.26, 1), (6.1, 1.02), fontsize=9,
            arrowprops={"arrowstyle": "-", "lw": .6})
ax.annotate("Product aromatic signals", (7.8, .35), (12.8, .63), fontsize=9,
            arrowprops={"arrowstyle": "-", "lw": .6})
ax = axes[1]
ax.plot(ppm, intensity, color=ink, lw=.7)
style(ax, (5, 0), (-.002, .043), .1)
ax.set_title("B  Low-intensity signals (expanded vertical scale)", loc="left", fontsize=10)
for x, y, txt, tx, ty in [(3.7317, .0082, "3.73", 3.72, .020),
                          (2.1747, .031, "2.175", 2.35, .035),
                          (1.418, .010, "1.42", 1.70, .020),
                          (1.2497, .021, "1.25", .99, .030),
                          (4.414, .0035, "4.41", 4.38, .012)]:
    ax.annotate(txt, (x, y), (tx, ty), ha="center", fontsize=9,
                arrowprops={"arrowstyle": "-", "lw": .5})
ax = axes[2]
ax.plot(ppm, intensity, color=ink, lw=.4)
style(ax, (14, 9), (-.001, .0012), .2)
ax.set_title("C  Acid-proton region (further vertical expansion); no distinct COOH resonance", loc="left", fontsize=10)
save(fig, "nmr_full")

fig, ax = plt.subplots(figsize=(9.1, 5.2))
fig.subplots_adjust(left=.085, right=.98, top=.86, bottom=.15)
fig.suptitle("Aromatic region: assignments and relative integrals", x=.085, y=.96,
             ha="left", fontsize=13, fontweight="bold")
ax.plot(ppm, intensity, color=ink, lw=.8)
style(ax, (8.30, 7.32), (-.11, .61), .02)
ax.xaxis.set_major_locator(MultipleLocator(.1))
for (label, high, low), w in zip(window_specs, windows):
    mask = (ppm <= high) & (ppm >= low)
    ax.fill_between(ppm[mask], 0, intensity[mask], color=accent, alpha=.16)
    # Windows and numerical integrals are printed beneath each group.
    level = -.025 if label in ["a", "b", "d"] else -.070
    ax.plot([high, high, low, low], [level+.007, level, level, level+.007], color=accent, lw=.8)
    ax.text((high+low)/2, level-.008, f"{label}: {w['relative_integral']:.2f}", color=accent,
            ha="center", va="top", fontsize=9)
for x, y, text in [(8.1912, .535, "a  8.19\nd, J = 8.3 Hz"),
                    (7.7089, .53, "b  7.71\nd, 8.3 Hz"),
                    (7.648, .405, "c\n7.66-7.64"),
                    (7.486, .465, "d\n7.50-7.47"),
                    (7.415, .285, "e\n7.43-7.40")]:
    ax.text(x, y, text, ha="center", fontsize=9)
fig.text(.085, .025, "Integrals: direct area of the supplied processed spectrum; a = 2.00. No quantitative purity is inferred.", fontsize=8.5)
save(fig, "nmr_aromatic")
print(json.dumps(results, indent=2))
